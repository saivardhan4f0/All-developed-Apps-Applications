# My Wage Tracker PWA

This is an installable Progressive Web App with Firebase email/password login and Firestore cross-device sync.

## 1. Create Firebase project
1. Go to Firebase Console and create a project.
2. Add a Web App. Copy the configuration into `firebase-config.js`.
3. Authentication > Sign-in method > enable Email/Password.
4. Firestore Database > Create database.
5. Firestore Rules > paste `firestore.rules` and publish.

## 2. Deploy
Install Node.js and Firebase CLI, then run:

```bash
npm install -g firebase-tools
firebase login
firebase init hosting
```

Choose your Firebase project; use the current folder as public directory; configure as single-page app = No. Then:

```bash
firebase deploy
```

Open the HTTPS URL on Android Chrome > menu > Add to Home screen / Install app.

## Security
Each user can access only `/users/{their Firebase UID}/...` under the included Firestore rules. Use a strong password and keep JSON backups in OneDrive or Google Drive.
